# Exercice 1

def concat_with_space(a,b):
    return a + ' ' + b

# Exercice 2

def format_with_fstring(a,b):
    return f'Hello {a}, you are {b} years old'