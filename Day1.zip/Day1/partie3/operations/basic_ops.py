def add(a, b):
    return a + b

def substract(a, b):
    return a - b