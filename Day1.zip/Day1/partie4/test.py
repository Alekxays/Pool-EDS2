import exercice1

print('Exercice 1 is imported and ready to use')