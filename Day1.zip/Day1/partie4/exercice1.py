def greet():
    print("Hello, World!")

def main():
    greet()

if __name__ == "__main__":
    main()