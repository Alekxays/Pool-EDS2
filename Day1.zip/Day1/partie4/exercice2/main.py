import other

other.display_message()