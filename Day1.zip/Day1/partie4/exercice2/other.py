def display_message():
    print("Je suis la fonction display_message du module other")
    return

if __name__ == "__main__":
    print("Je suis le main du module other")
    display_message()